-- 该脚本不要直接执行， 注意维护菜单的父节点ID 默认 父节点-1 , 

-- 菜单SQL
insert into sys_menu ( menu_id,parent_id, path, permission, menu_type, icon, del_flag, create_time, sort_order, update_time, name)
values (1732408796426, '-1', '/admin/process/index', '', '0', 'icon-bangzhushouji', '0', null , '8', null , 'demo 表管理');

-- 菜单对应按钮SQL
insert into sys_menu ( menu_id,parent_id, permission, menu_type, path, icon, del_flag, create_time, sort_order, update_time, name)
values (1732408796427,1732408796426, 'admin_process_view', '1', null, '1',  '0', null, '0', null, 'demo 表查看');

insert into sys_menu ( menu_id,parent_id, permission, menu_type, path, icon, del_flag, create_time, sort_order, update_time, name)
values (1732408796428,1732408796426, 'admin_process_add', '1', null, '1',  '0', null, '1', null, 'demo 表新增');

insert into sys_menu (menu_id, parent_id, permission, menu_type, path, icon,  del_flag, create_time, sort_order, update_time, name)
values (1732408796429,1732408796426, 'admin_process_edit', '1', null, '1',  '0', null, '2', null, 'demo 表修改');

insert into sys_menu (menu_id, parent_id, permission, menu_type, path, icon, del_flag, create_time, sort_order, update_time, name)
values (1732408796430,1732408796426, 'admin_process_del', '1', null, '1',  '0', null, '3', null, 'demo 表删除');

insert into sys_menu ( menu_id,parent_id, permission, menu_type, path, icon, del_flag, create_time, sort_order, update_time, name)
values (1732408796431,1732408796426, 'admin_process_export', '1', null, '1',  '0', null, '3', null, '导入导出');