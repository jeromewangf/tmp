package com.pig4cloud.pig.admin.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.pig4cloud.pig.admin.entity.ProcessEntity;
import com.pig4cloud.pig.admin.mapper.ProcessMapper;
import com.pig4cloud.pig.admin.service.ProcessService;
import org.springframework.stereotype.Service;

/**
 * demo 表
 *
 * @author pig
 * @date 2024-11-24 08:39:56
 */
@Service
public class ProcessServiceImpl extends ServiceImpl<ProcessMapper, ProcessEntity> implements ProcessService {

}
