package com.pig4cloud.pig.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.pig4cloud.pig.admin.entity.ProcessEntity;

public interface ProcessService extends IService<ProcessEntity> {

}
